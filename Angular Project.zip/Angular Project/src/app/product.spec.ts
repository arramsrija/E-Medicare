import { Product } from './product'; 

describe('Product', () => {
  it('should create an instance', () => {
    const product = new Product(
      1,                
      'Sample Product', 
      10.99,            
      'sample.jpg',     
      'Sample Type',    
      'A sample product description.' 
    );

    expect(product).toBeTruthy(); 
  });
});